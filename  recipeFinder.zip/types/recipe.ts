export interface Recipe {
  id: number;
  title: string;
  image: string;
  summary?: string;
  readyInMinutes?: number;
  servings?: number;
  extendedIngredients?: (Ingredient | { original: string })[];
  analyzedInstructions?: InstructionSet[];
  sourceUrl?: string;
}

export interface Ingredient {
  id: number;
  name: string;
  amount: number;
  unit: string;
  original?: string;
}

export interface InstructionStep {
  number: number;
  step: string;
}

export interface InstructionSet {
  steps: InstructionStep[];
}

export interface SearchResponse {
  results: Recipe[];
  totalResults: number;
  offset: number;
  number: number;
}

export interface SearchFilters {
  diet?: string;
  type?: string;
  cuisine?: string;
}