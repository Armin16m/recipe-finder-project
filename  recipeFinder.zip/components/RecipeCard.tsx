import Link from 'next/link'
import { Recipe } from '../types/recipe'
import styles from '../styles/RecipeCard.module.css'

interface RecipeCardProps {
  recipe: Recipe;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe }) => {
  const stripHtml = (html: string | undefined): string => {
    if (!html) return ''
    return html.replace(/<[^>]*>/g, '')
  }

  return (
    <div className={styles.card}>
      <img 
        src={recipe.image || '/placeholder-recipe.jpg'} 
        alt={recipe.title}
        className={styles.image}
      />
      
      <div className={styles.content}>
        <h3 className={styles.title}>{recipe.title}</h3>
        {recipe.summary && (
          <p className={styles.summary}>
            {stripHtml(recipe.summary).substring(0, 100)}...
          </p>
        )}
        
        <div className={styles.info}>
          {recipe.readyInMinutes && (
            <span className={styles.time}>⏱️ {recipe.readyInMinutes} دقیقه</span>
          )}
          {recipe.servings && (
            <span className={styles.servings}>👥 {recipe.servings} نفر</span>
          )}
        </div>
        
        <Link href={`/recipe/${recipe.id}`} className={styles.button}>
          جزئیات بیشتر
        </Link>
      </div>
    </div>
  )
}

export default RecipeCard