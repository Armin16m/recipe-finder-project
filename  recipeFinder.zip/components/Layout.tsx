import Head from 'next/head'
import Link from 'next/link'
import { ReactNode } from 'react'
import styles from '../styles/Layout.module.css'

interface LayoutProps {
  children: ReactNode;
  title?: string;
}

const Layout: React.FC<LayoutProps> = ({ children, title = 'Recipe Finder' }) => {
  return (
    <>
      <Head>
        <title>{title}</title>
        <meta name="description" content="جستجوگر دستور غذا - بهترین دستور غذاها را پیدا کنید" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <nav className={styles.nav}>
        <div className={styles.navContainer}>
          <Link href="/" className={styles.logo}>
            Recipe Finder
          </Link>
          
          <div className={styles.navLinks}>
            <Link href="/">خانه</Link>
            <Link href="/favorites">علاقه‌مندی‌ها</Link>
            <Link href="/about">درباره ما</Link>
          </div>
        </div>
      </nav>

      <main className={styles.main}>
        {children}
      </main>

      <footer className={styles.footer}>
        <p>&copy; 2024 Recipe Finder. تمامی حقوق محفوظ است.</p>
      </footer>
    </>
  )
}

export default Layout