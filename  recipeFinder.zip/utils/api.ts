const API_KEY = '8dc843791d3949988449d656ce1473f7';
const BASE_URL = 'https://api.spoonacular.com/recipes';

interface Recipe {
  id: number;
  title: string;
  image: string;
  summary?: string;
  extendedIngredients?: {
    original: string;
  }[];
  instructions?: string;
  readyInMinutes?: number;
  servings?: number;
}

interface SearchResults {
  results: Recipe[];
  totalResults: number;
}

export const ApiService = {

  async searchRecipes(query: string, page: number, options?: {
  includeIngredients?: string;
  diet?: string;
  number?: number;
}): Promise<SearchResults> {
    const params = new URLSearchParams({
      apiKey: API_KEY,
      query: query,
      ...(options?.includeIngredients && { includeIngredients: options.includeIngredients }),
      ...(options?.diet && { diet: options.diet }),
      number: options?.number?.toString() || '10',
      instructionsRequired: 'true',
      addRecipeInformation: 'true'
    });

    try {
      const response = await fetch(`${BASE_URL}/complexSearch?${params}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error searching recipes:', error);
      throw error;
    }
  },


  async getRecipeById(id: number): Promise<Recipe> {
    try {
      const response = await fetch(
        `${BASE_URL}/${id}/information?apiKey=${API_KEY}&includeNutrition=false`
      );
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error(`Error fetching recipe ${id}:`, error);
      throw error;
    }
  },


  async getRandomRecipes(number: number = 5): Promise<{ recipes: Recipe[] }> {
    try {
      const response = await fetch(
        `${BASE_URL}/random?apiKey=${API_KEY}&number=${number}`
      );
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching random recipes:', error);
      throw error;
    }
  },

  async searchByIngredients(ingredients: string[], number: number = 5): Promise<Recipe[]> {
    try {
      const response = await fetch(
        `${BASE_URL}/findByIngredients?apiKey=${API_KEY}&ingredients=${ingredients.join(',')}&number=${number}&ranking=1`
      );
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error searching by ingredients:', error);
      throw error;
    }
  }
};