import { useState, useEffect, ChangeEvent } from 'react'
import { useRouter } from 'next/router'
import Layout from '../components/Layout'
import RecipeCard from '../components/RecipeCard'
import { ApiService } from '../utils/api'
import { Recipe, SearchFilters } from '../types/recipe'
import styles from '../styles/Search.module.css'

const Search: React.FC = () => {
  const router = useRouter()
  const { q, diet, type } = router.query as { q?: string; diet?: string; type?: string }
  const [recipes, setRecipes] = useState<Recipe[]>([])
  const [loading, setLoading] = useState<boolean>(false)
  const [currentPage, setCurrentPage] = useState<number>(1)
  const [totalResults, setTotalResults] = useState<number>(0)

  const fetchRecipes = async (query: string, page: number = 1, filters: SearchFilters = {}) => {
    setLoading(true)
    try {
      const data = await ApiService.searchRecipes(query, page, filters)
      setRecipes(data.results)
      setTotalResults(data.totalResults)
    } catch (error) {
      console.error('Error fetching recipes:', error)
    }
    setLoading(false)
  }

  useEffect(() => {
    if (q) {
      fetchRecipes(q, currentPage, { diet, type })
    }
  }, [q, currentPage, diet, type])

  const handleFilterChange = (filterType: string, value: string) => {
    router.push({
      pathname: '/search',
      query: { ...router.query, [filterType]: value }
    })
  }

  const handleDietChange = (e: ChangeEvent<HTMLSelectElement>) => {
    handleFilterChange('diet', e.target.value)
  }

  const handleTypeChange = (e: ChangeEvent<HTMLSelectElement>) => {
    handleFilterChange('type', e.target.value)
  }

  return (
    <Layout>
      <div className={styles.container}>
        <div className={styles.filters}>
          <select onChange={handleDietChange} value={diet || ''}>
            <option value="">همه رژیم‌ها</option>
            <option value="vegetarian">گیاهخواری</option>
            <option value="vegan">وگان</option>
            <option value="ketogenic">کتوژنیک</option>
            <option value="gluten free">بدون گلوتن</option>
          </select>
          
          <select onChange={handleTypeChange} value={type || ''}>
            <option value="">همه انواع</option>
            <option value="main course">غذای اصلی</option>
            <option value="dessert">دسر</option>
            <option value="appetizer">پیش غذا</option>
            <option value="breakfast">صبحانه</option>
          </select>
        </div>

        {loading ? (
          <div className={styles.loading}>در حال بارگذاری...</div>
        ) : (
          <>
            <div className={styles.resultsGrid}>
              {recipes.map(recipe => (
                <RecipeCard key={recipe.id} recipe={recipe} />
              ))}
            </div>
            
            {totalResults > 12 && (
              <div className={styles.pagination}>
                <button 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  قبلی
                </button>
                <span>صفحه {currentPage}</span>
                <button 
                  onClick={() => setCurrentPage(prev => prev + 1)}
                  disabled={currentPage * 12 >= totalResults}
                >
                  بعدی
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </Layout>
  )
}

export default Search