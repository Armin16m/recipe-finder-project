/* eslint-disable @typescript-eslint/no-unused-vars */
import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import { GetServerSideProps } from 'next'
import Layout from '../../components/Layout'
import { ApiService } from '../../utils/api'
import { Recipe } from '../../types/recipe'
import styles from '../../styles/Recipe.module.css'

interface RecipeDetailProps {
  recipeId: string;
}

const RecipeDetail: React.FC<RecipeDetailProps> = ({ recipeId }) => {
  const router = useRouter()
  const [recipe, setRecipe] = useState<Recipe | null>(null)
  const [loading, setLoading] = useState<boolean>(true)
  const [isFavorite, setIsFavorite] = useState<boolean>(false)

  useEffect(() => {
    if (recipeId) {
      fetchRecipeDetail(recipeId)
      checkIfFavorite(recipeId)
    }
  }, [recipeId])

  const fetchRecipeDetail = async (id: string) => {
    try {
      const data = await ApiService.getRecipeById(id)
      setRecipe(data)
    } catch (error) {
      console.error('Error fetching recipe detail:', error)
    }
    setLoading(false)
  }

  const checkIfFavorite = (id: string) => {
    if (typeof window !== 'undefined') {
      const favorites = JSON.parse(localStorage.getItem('favorites') || '[]') as Recipe[]
      setIsFavorite(favorites.some(fav => fav.id.toString() === id))
    }
  }

  const toggleFavorite = () => {
    if (typeof window !== 'undefined' && recipe) {
      const favorites = JSON.parse(localStorage.getItem('favorites') || '[]') as Recipe[]
      
      if (isFavorite) {
        const newFavorites = favorites.filter(fav => fav.id !== recipe.id)
        localStorage.setItem('favorites', JSON.stringify(newFavorites))
        setIsFavorite(false)
      } else {
        const newFavorites = [...favorites, {
          id: recipe.id,
          title: recipe.title,
          image: recipe.image,
          summary: recipe.summary
        }]
        localStorage.setItem('favorites', JSON.stringify(newFavorites))
        setIsFavorite(true)
      }
    }
  }

  const stripHtml = (html: string | undefined): string => {
    if (!html) return ''
    return html.replace(/<[^>]*>/g, '')
  }

  if (loading) {
    return (
      <Layout>
        <div className={styles.loading}>در حال بارگذاری...</div>
      </Layout>
    )
  }

  if (!recipe) {
    return (
      <Layout>
        <div className={styles.container}>دستور غذا یافت نشد</div>
      </Layout>
    )
  }

  return (
    <Layout title={`${recipe.title} - Recipe Finder`}>
      <div className={styles.container}>
        <img src={recipe.image} alt={recipe.title} className={styles.image} />
        
        <div className={styles.content}>
          <h1 className={styles.title}>{recipe.title}</h1>
          
          <div className={styles.info}>
            {recipe.readyInMinutes && <span>زمان: {recipe.readyInMinutes} دقیقه</span>}
            {recipe.servings && <span>تعداد نفرات: {recipe.servings}</span>}
          </div>

          <button 
            onClick={toggleFavorite}
            className={`${styles.favoriteButton} ${isFavorite ? styles.favorited : ''}`}
          >
            {isFavorite ? 'حذف از علاقه‌مندی‌ها' : 'ذخیره در علاقه‌مندی‌ها'}
          </button>

          {recipe.summary && (
            <div className={styles.section}>
              <h2>توضیحات:</h2>
              <p>{stripHtml(recipe.summary)}</p>
            </div>
          )}

          {recipe.extendedIngredients && recipe.extendedIngredients.length > 0 && (
            <div className={styles.section}>
              <h2>مواد لازم:</h2>
              <ul>
                {recipe.extendedIngredients.map((ingredient, index) => (
                  <li key={index}>{ingredient.original}</li>
                ))}
              </ul>
            </div>
          )}

          {recipe.analyzedInstructions && recipe.analyzedInstructions[0]?.steps && (
            <div className={styles.section}>
              <h2>مراحل تهیه:</h2>
              <ol>
                {recipe.analyzedInstructions[0].steps.map((step) => (
                  <li key={step.number}>{step.step}</li>
                ))}
              </ol>
            </div>
          )}
        </div>
      </div>
    </Layout>
  )
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const { id } = context.params as { id: string }
  
  return {
    props: {
      recipeId: id,
    },
  }
}

export default RecipeDetail