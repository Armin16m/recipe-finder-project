import Layout from '../components/Layout'
import styles from '../styles/About.module.css'

const About: React.FC = () => {
  return (
    <Layout title="درباره ما - Recipe Finder">
      <div className={styles.container}>
        <h1>درباره Recipe Finder</h1>
        <p>
          Recipe Finder یک اپلیکیشن وب برای جستجو و کشف دستور غذاهای مختلف است.
          شما می‌توانید با استفاده از مواد اولیه، نام غذا یا کلمات کلیدی، 
          بهترین دستور غذاها را پیدا کنید.
        </p>
        <p>
          این پروژه با استفاده از Next.js، TypeScript و API سرویس Spoonacular ساخته شده است.
        </p>
        
        <div className={styles.features}>
          <h2>ویژگی‌ها:</h2>
          <ul>
            <li>جستجوی پیشرفته دستور غذاها</li>
            <li>فیلترهای مختلف (رژیم غذایی، نوع غذا)</li>
            <li>ذخیره علاقه‌مندی‌ها</li>
            <li>طراحی ریسپانسیو</li>
            <li>پشتیبانی از زبان فارسی</li>
          </ul>
        </div>
      </div>
    </Layout>
  )
}

export default About