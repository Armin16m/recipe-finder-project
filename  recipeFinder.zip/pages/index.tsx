/* eslint-disable @next/next/no-img-element */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useEffect, FormEvent } from 'react';
import { useRouter } from 'next/router';
import Layout from '../components/Layout';
import styles from '../styles/Home.module.css';

const Home: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [randomRecipes, setRandomRecipes] = useState<any[]>([]); 
  const router = useRouter();

  
  useEffect(() => {
    const fetchRandomRecipes = async () => {
      const API_KEY = '8dc843791d3949988449d656ce1473f7'; 
      const url = `https://api.spoonacular.com/recipes/random?apiKey=${API_KEY}&number=3`;

      try {
        const response = await fetch(url);
        const data = await response.json();
        if (data.recipes) {
          setRandomRecipes(data.recipes);
        } else {
          setRandomRecipes([]);
        }
      } catch (error) {
        console.error('خطا در دریافت دستور پخت‌های تصادفی:', error);
        setRandomRecipes([]);
      }
    };

    fetchRandomRecipes();
  }, []); 

  const handleSearch = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSuggestions([]);
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const fetchSuggestions = async (query: string) => {
    const API_KEY = '8dc843791d3949988449d656ce1473f7';
    const url = `https://api.spoonacular.com/recipes/complexSearch?apiKey=${API_KEY}&query=${encodeURIComponent(query)}&number=3`;

    try {
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      if (data.results) {
        setSuggestions(data.results);
      } else {
        setSuggestions([]);
      }
    } catch (error) {
      console.error('خطا در دریافت پیشنهادها:', error);
      setSuggestions([]);
    }
  };

  return (
    <Layout>
      <div className={styles.container}>
        <div className={styles.hero}>
          <h1 className={styles.title}>جستجوگر دستور غذا</h1>
          <p className={styles.subtitle}>بهترین دستور غذاها را پیدا کنید</p>
          
          <form onSubmit={handleSearch} className={styles.searchForm}>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                const value = e.target.value;
                setSearchQuery(value);
                if (value.trim()) {
                  fetchSuggestions(value);
                } else {
                  setSuggestions([]);
                }
              }}
              placeholder="مواد اولیه یا نام غذا را جستجو کنید..."
              className={styles.searchInput}
            />
            <button type="submit" className={styles.searchButton}>
              جستجو
            </button>
          </form>

          {suggestions.length > 0 && (
            <div className={styles.suggestionBox}>
              <ul className={styles.suggestionList}>
                {suggestions.map((suggestion, index) => (
                  <li key={index} className={styles.suggestionItem}>
                    <a
                      href={`/recipe/${suggestion.id}`}
                      className={styles.suggestionLink}
                      onClick={(e) => {
                        e.preventDefault();
                        setSearchQuery(suggestion.title);
                        setSuggestions([]);
                        router.push(`/search?q=${encodeURIComponent(suggestion.title)}`);
                      }}
                    >
                      {suggestion.title}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {randomRecipes.length > 0 && (
            <div className={styles.randomRecipes}>
              <div className={styles.recipesFlex}>
                {randomRecipes.map((recipe) => (
                  <div key={recipe.id} className={styles.recipeCard}>
                    <img src={recipe.image} alt={recipe.title} className={styles.recipeImage} />
                    <h3 className={styles.recipeTitle}>{recipe.title}</h3>
                    <a href={`/recipe/${recipe.id}`} className={styles.recipeLink}>
                      مشاهده جزئیات
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Home;