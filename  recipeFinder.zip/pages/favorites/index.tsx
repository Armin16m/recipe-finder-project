import { useState, useEffect } from 'react'
import Layout from '../../components/Layout'
import RecipeCard from '../../components/RecipeCard'
import { Recipe } from '../../types/recipe'
import styles from '../../styles/Favorite.module.css'

const Favorites: React.FC = () => {
  const [favorites, setFavorites] = useState<Recipe[]>([])

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedFavorites = JSON.parse(localStorage.getItem('favorites') || '[]') as Recipe[]
      setFavorites(savedFavorites)
    }
  }, [])

  const removeFavorite = (id: number) => {
    if (typeof window !== 'undefined') {
      const newFavorites = favorites.filter(fav => fav.id !== id)
      localStorage.setItem('favorites', JSON.stringify(newFavorites))
      setFavorites(newFavorites)
    }
  }

  return (
    <Layout title="علاقه‌مندی‌ها - Recipe Finder">
      <div className={styles.container}>
        <h1 className={styles.title}>علاقه‌مندی‌های من</h1>
        
        {favorites.length === 0 ? (
          <div className={styles.empty}>
            <p>هنوز هیچ دستور غذایی را ذخیره نکرده‌اید!</p>
            <p>شروع به ذخیره کردن دستور غذاهای مورد علاقه‌تان کنید.</p>
          </div>
        ) : (
          <div className={styles.favoritesGrid}>
            {favorites.map(recipe => (
              <div key={recipe.id} className={styles.favoriteItem}>
                <RecipeCard recipe={recipe} />
                <button 
                  onClick={() => removeFavorite(recipe.id)}
                  className={styles.removeButton}
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  )
}

export default Favorites